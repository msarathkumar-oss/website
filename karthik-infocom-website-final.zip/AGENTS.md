<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep verified Karthik Infocom business content in `src/lib/site-data.ts` so all routes share one source of truth.
- Keep shared site chrome in the root route and page-specific content in dedicated TanStack route files for stable navigation and SEO.
- Keep verified business details, client names, and contact destinations in the shared site-data module so all public pages remain consistent.
- Use a pre-filled WhatsApp handoff for service requests because the static website does not store customer submissions.
