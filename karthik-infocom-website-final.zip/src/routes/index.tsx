import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BadgeCheck, Clock3, MapPin, Phone, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroAsset from "@/assets/karthik-hero.jpg.asset.json";
import aboutAsset from "@/assets/karthik-about.jpg.asset.json";
import { advantages, brands, business, clients, processSteps, services } from "@/lib/site-data";

const heroImage = heroAsset.url;
const aboutImage = aboutAsset.url;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Karthik Infocom | IT Hardware Repair & Computer Services in Guntur" },
      { name: "description", content: "Professional IT hardware repair, computer and laptop service solutions from Karthik Infocom in Guntur." },
      { property: "og:title", content: "Karthik Infocom | IT Hardware Services in Guntur" },
      { property: "og:description", content: "Authorized IT hardware installation, repairs, maintenance and technology support in Guntur." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [{ type: "application/ld+json", children: JSON.stringify({ "@context": "https://schema.org", "@type": "LocalBusiness", name: business.name, description: "IT hardware installation, repair, maintenance and technology support.", telephone: business.phoneDisplay, email: business.email, address: { "@type": "PostalAddress", addressLocality: "Guntur", addressRegion: "Andhra Pradesh", addressCountry: "IN" }, openingHours: "Mo-Sa 10:00-20:00" }) }],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <section className="relative isolate h-[calc(100svh-8rem)] min-h-[560px] max-h-[720px] overflow-hidden bg-footer text-footer-foreground lg:h-auto lg:min-h-[760px] lg:max-h-none">
        <img src={heroImage} alt="Technician repairing laptop hardware in a professional service workshop" width={1600} height={1104} fetchPriority="high" className="absolute inset-0 -z-20 size-full object-cover object-[65%_center]" />
        <div className="absolute inset-0 -z-10 bg-hero-overlay" />
        <div className="site-container flex h-full items-end pb-12 pt-20 lg:min-h-[760px] lg:items-center lg:pb-24 lg:pt-24">
          <div className="max-w-3xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-hero-line bg-hero-chip px-3 py-2 text-xs font-semibold uppercase tracking-[0.12em] text-hero-muted backdrop-blur"><BadgeCheck className="size-4 text-success" aria-hidden="true" /> Trusted IT Hardware & Technology Support</span>
            <h1 className="mt-6 text-4xl font-extrabold leading-[1.08] text-footer-foreground sm:text-5xl lg:text-7xl">Reliable IT Hardware Services for Your Business & Home</h1>
            <p className="mt-6 max-w-2xl text-base leading-7 text-hero-muted sm:text-lg">Professional computer, laptop, hardware repair and technology support services in Guntur.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button asChild size="lg"><Link to="/contact">Request a Service <ArrowRight aria-hidden="true" /></Link></Button>
              <Button asChild size="lg" variant="heroOutline"><a href={business.phoneHref}><Phone aria-hidden="true" /> Call Us</a></Button>
            </div>
            <div className="mt-9 flex flex-wrap gap-x-6 gap-y-3 text-sm text-hero-muted"><span className="flex items-center gap-2"><ShieldCheck className="size-4 text-success" /> Authorized service</span><span className="flex items-center gap-2"><MapPin className="size-4 text-success" /> Local Guntur support</span><span className="flex items-center gap-2"><Clock3 className="size-4 text-success" /> Mon–Sat, 10am–8pm</span></div>
          </div>
        </div>
      </section>

      <section className="border-b border-border bg-surface py-7" aria-label="Authorized brands"><div className="site-container"><p className="text-center text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">Authorized service partner for</p><div className="mt-5 flex flex-wrap items-center justify-center gap-x-9 gap-y-4">{brands.map((brand) => <span key={brand} className="text-base font-bold text-brand-muted sm:text-lg">{brand}</span>)}</div></div></section>

      <section className="section-space bg-background"><div className="site-container"><div className="max-w-2xl"><span className="eyebrow">Our Services</span><h2 className="mt-5 text-3xl font-bold sm:text-5xl">End-to-end support for your IT hardware</h2><p className="mt-4 text-lg leading-8 text-muted-foreground">From installation to ongoing maintenance, our team supports businesses and individuals across Guntur.</p></div><div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">{services.map((service, index) => { const Icon = service.icon; return <article key={service.slug} className={`group rounded-2xl border border-border bg-card p-6 shadow-card transition-all duration-200 hover:-translate-y-1 hover:border-primary/25 ${index === 0 ? "lg:col-span-2" : ""}`}><span className="grid size-11 place-items-center rounded-xl bg-accent text-primary"><Icon className="size-5" aria-hidden="true" /></span><h3 className="mt-6 text-xl font-bold">{service.title}</h3><p className="mt-3 leading-7 text-muted-foreground">{service.summary}</p><Link to="/services" hash={service.slug} className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-primary">View service <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" /></Link></article>; })}</div></div></section>

      <section className="section-space bg-surface"><div className="site-container grid items-center gap-12 lg:grid-cols-[1.05fr_.95fr]"><div className="overflow-hidden rounded-2xl"><img src={aboutImage} alt="Technician diagnosing laptop components at the Karthik Infocom service workbench" width={1200} height={912} loading="lazy" className="aspect-[4/3] size-full object-cover" /></div><div><span className="eyebrow">About Karthik Infocom</span><h2 className="mt-5 text-3xl font-bold sm:text-5xl">Authorized expertise, delivered locally</h2><p className="mt-5 text-lg leading-8 text-muted-foreground">Karthik Infocom is an authorized service partner for leading IT brands in Guntur, serving businesses and individuals with installation, repair, maintenance and training services.</p><p className="mt-4 leading-7 text-muted-foreground">Established in 2008, our team focuses on customer satisfaction, product reliability and service delivered through manufacturer-approved procedures.</p><Button asChild variant="outline" size="lg" className="mt-8"><Link to="/about">Our company <ArrowRight /></Link></Button></div></div></section>

      <section className="section-space bg-background"><div className="site-container"><div className="mx-auto max-w-2xl text-center"><span className="eyebrow">Why Choose Us</span><h2 className="mt-5 text-3xl font-bold sm:text-5xl">Technical care built around reliability</h2></div><div className="mt-12 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">{advantages.slice(0, 6).map((item) => { const Icon = item.icon; return <article key={item.title} className="border-l-2 border-primary/20 pl-5"><Icon className="size-6 text-primary" aria-hidden="true" /><h3 className="mt-4 text-lg font-bold">{item.title}</h3><p className="mt-2 leading-7 text-muted-foreground">{item.text}</p></article>; })}</div></div></section>

      <section className="section-space border-y border-border bg-surface"><div className="site-container"><div className="flex flex-col justify-between gap-6 md:flex-row md:items-end"><div className="max-w-2xl"><span className="eyebrow">Our Clients</span><h2 className="mt-5 text-3xl font-bold sm:text-5xl">Trusted across Guntur's business community</h2><p className="mt-4 text-lg leading-8 text-muted-foreground">Organizations across retail, healthcare, hospitality, manufacturing and professional services rely on Karthik Infocom.</p></div><Button asChild variant="outline" size="lg"><Link to="/clients">View all {clients.length} clients <ArrowRight /></Link></Button></div><div className="mt-10 grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">{clients.slice(0, 9).map((client) => <div key={client} className="flex min-h-20 items-center bg-card px-5 py-4 font-semibold text-card-foreground">{client}</div>)}</div></div></section>

      <section className="section-space bg-footer text-footer-foreground"><div className="site-container"><div className="max-w-2xl"><span className="text-xs font-bold uppercase tracking-[0.14em] text-hero-accent">Service Process</span><h2 className="mt-5 text-3xl font-bold sm:text-5xl">A clear path from issue to handover</h2></div><ol className="mt-12 grid gap-8 lg:grid-cols-4">{processSteps.map((step, index) => <li key={step.number} className="relative border-t border-footer-border pt-6"><span className="text-sm font-bold text-hero-accent">{step.number}</span><h3 className="mt-4 text-xl font-bold">{step.title}</h3><p className="mt-3 leading-7 text-footer-muted">{step.text}</p>{index < processSteps.length - 1 && <ArrowRight className="absolute -right-5 top-5 hidden size-5 text-footer-border lg:block" aria-hidden="true" />}</li>)}</ol></div></section>

      <section className="section-space bg-surface"><div className="site-container"><div className="rounded-2xl bg-primary px-6 py-12 text-center text-primary-foreground shadow-brand sm:px-12"><h2 className="text-3xl font-bold sm:text-5xl">Need expert help with your IT hardware?</h2><p className="mx-auto mt-4 max-w-2xl text-lg text-primary-soft">Contact Karthik Infocom for service support in Guntur.</p><div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row"><Button asChild size="lg" variant="inverse"><Link to="/contact">Request Service</Link></Button><Button asChild size="lg" variant="primaryOutline"><a href={business.phoneHref}><Phone /> {business.phoneDisplay}</a></Button></div></div></div></section>
    </>
  );
}
