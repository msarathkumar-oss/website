import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { Button } from "@/components/ui/button";
import { services } from "@/lib/site-data";

export const Route = createFileRoute("/services")({
  head: () => ({ meta: [{ title: "IT Hardware Services in Guntur | Karthik Infocom" }, { name: "description", content: "Explore Karthik Infocom installation, repairs, maintenance, extended warranty, training, accessories and parts services in Guntur." }, { property: "og:title", content: "IT Hardware Services | Karthik Infocom" }, { property: "og:description", content: "End-to-end IT hardware installation, repair and maintenance services in Guntur." }, { property: "og:type", content: "website" }, { property: "og:url", content: "/services" }, { name: "twitter:card", content: "summary_large_image" }], links: [{ rel: "canonical", href: "/services" }] }),
  component: ServicesPage,
});

function ServicesPage() {
  return <><PageHero eyebrow="Our Services" title="End-to-end IT hardware solutions" description="Professional support from initial installation and configuration through repairs, maintenance, parts and practical product training." /><section className="section-space"><div className="site-container grid gap-6">{services.map((service, index) => { const Icon = service.icon; return <article id={service.slug} key={service.slug} className="scroll-mt-28 grid gap-8 rounded-2xl border border-border bg-card p-6 shadow-card sm:p-8 lg:grid-cols-[.75fr_1.25fr] lg:items-start"><div><div className="flex items-center gap-4"><span className="grid size-12 shrink-0 place-items-center rounded-xl bg-accent text-primary"><Icon /></span><span className="text-sm font-bold text-muted-foreground">0{index + 1}</span></div><h2 className="mt-6 text-2xl font-bold sm:text-3xl">{service.title}</h2><p className="mt-3 leading-7 text-muted-foreground">{service.summary}</p></div><ul className="grid gap-3 sm:grid-cols-2">{service.details.map((detail) => <li key={detail} className="flex gap-3 rounded-xl bg-accent/60 p-4 text-sm font-medium"><Check className="mt-0.5 size-4 shrink-0 text-success" aria-hidden="true" />{detail}</li>)}</ul></article>; })}<div className="mt-4 flex justify-center"><Button asChild size="lg"><Link to="/contact">Request a service <ArrowRight /></Link></Button></div></div></section></>;
}