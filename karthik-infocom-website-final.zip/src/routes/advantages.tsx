import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/advantages")({ beforeLoad: () => { throw redirect({ to: "/why-us", statusCode: 301 }); } });