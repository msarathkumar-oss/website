import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Building2, MessageCircle } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { Button } from "@/components/ui/button";
import { business, clients } from "@/lib/site-data";

export const Route = createFileRoute("/clients")({
  head: () => ({ meta: [
    { title: "Our Clients | Karthik Infocom Guntur" },
    { name: "description", content: "Organizations across retail, healthcare, hospitality, manufacturing and professional services supported by Karthik Infocom." },
    { property: "og:title", content: "Our Clients | Karthik Infocom" },
    { property: "og:description", content: "Trusted IT hardware service relationships across Guntur's business community." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: ClientsPage,
});

function ClientsPage() {
  return <><PageHero eyebrow="Our Clients" title="Trusted by businesses across Guntur" description="Long-standing service relationships across retail, healthcare, hospitality, manufacturing, automotive and professional services." /><section className="section-space"><div className="site-container"><div className="grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">{clients.map((client, index) => <article key={client} className="group flex min-h-28 items-start gap-4 bg-card p-5 transition-colors hover:bg-accent"><span className="grid size-10 shrink-0 place-items-center rounded-lg bg-accent text-primary group-hover:bg-background"><Building2 className="size-5" /></span><div><span className="text-xs font-bold text-muted-foreground">{String(index + 1).padStart(2, "0")}</span><h2 className="mt-1 font-semibold leading-6 text-card-foreground">{client}</h2></div></article>)}</div><div className="mt-14 flex flex-col items-start justify-between gap-6 border-t border-border pt-10 md:flex-row md:items-center"><div><h2 className="text-2xl font-bold">Looking for a reliable IT service partner?</h2><p className="mt-2 text-muted-foreground">Speak directly with our Guntur support team.</p></div><div className="flex flex-col gap-3 sm:flex-row"><Button asChild variant="whatsapp" size="lg"><a href={business.whatsappHref} target="_blank" rel="noreferrer"><MessageCircle /> WhatsApp Us</a></Button><Button asChild size="lg"><Link to="/contact">Request Service <ArrowRight /></Link></Button></div></div></div></section></>;
}
