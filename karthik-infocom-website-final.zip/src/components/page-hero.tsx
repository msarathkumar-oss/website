import type { ReactNode } from "react";

export function PageHero({ eyebrow, title, description, children }: { eyebrow: string; title: string; description: string; children?: ReactNode }) {
  return (
    <section className="tech-grid border-b border-border bg-surface py-16 sm:py-20">
      <div className="site-container">
        <span className="eyebrow">{eyebrow}</span>
        <h1 className="mt-5 max-w-4xl text-4xl font-bold leading-tight text-foreground sm:text-5xl lg:text-6xl">{title}</h1>
        <p className="mt-5 max-w-2xl text-lg leading-8 text-muted-foreground">{description}</p>
        {children && <div className="mt-8">{children}</div>}
      </div>
    </section>
  );
}