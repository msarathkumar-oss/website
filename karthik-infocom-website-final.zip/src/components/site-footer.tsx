import { Link } from "@tanstack/react-router";
import { Clock3, Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { BrandLogo } from "@/components/brand-logo";
import { brands, business, services } from "@/lib/site-data";

export function SiteFooter() {
  return (
    <footer className="bg-footer text-footer-foreground">
      <div className="site-container grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-4">
        <div><div className="inline-flex rounded-md bg-surface p-2"><BrandLogo className="h-20" /></div><p className="mt-5 max-w-sm text-sm leading-6 text-footer-muted">Authorized IT hardware installation, repair, maintenance and support for businesses and individuals in Guntur.</p><p className="mt-4 text-xs font-semibold uppercase tracking-[0.14em] text-footer-muted">Supporting {brands.length} leading brands</p></div>
        <div><h2 className="text-sm font-semibold uppercase tracking-[0.12em]">Quick Links</h2><div className="mt-4 grid gap-3 text-sm text-footer-muted"><Link to="/services">Services</Link><Link to="/about">About</Link><Link to="/clients">Clients</Link><Link to="/why-us">Why Us</Link><Link to="/process">Process</Link><Link to="/contact">Contact</Link></div></div>
        <div><h2 className="text-sm font-semibold uppercase tracking-[0.12em]">Services</h2><div className="mt-4 grid gap-3 text-sm text-footer-muted">{services.map((service) => <Link key={service.slug} to="/services" hash={service.slug}>{service.title}</Link>)}</div></div>
        <div><h2 className="text-sm font-semibold uppercase tracking-[0.12em]">Contact</h2><address className="mt-4 grid gap-4 text-sm not-italic text-footer-muted"><a href={business.phoneHref} className="flex gap-3"><Phone className="mt-0.5 size-4 shrink-0" />{business.phoneDisplay}</a><a href={business.whatsappHref} target="_blank" rel="noreferrer" className="flex gap-3"><MessageCircle className="mt-0.5 size-4 shrink-0" />WhatsApp us</a><a href={`mailto:${business.email}`} className="flex min-w-0 gap-3"><Mail className="mt-0.5 size-4 shrink-0" /><span className="break-all">{business.email}</span></a><a href={business.mapsUrl} target="_blank" rel="noreferrer" className="flex gap-3"><MapPin className="mt-0.5 size-4 shrink-0" />{business.address}</a><span className="flex gap-3"><Clock3 className="mt-0.5 size-4 shrink-0" />{business.hours}</span></address></div>
      </div>
      <div className="border-t border-footer-border"><div className="site-container py-5 text-center text-xs text-footer-muted sm:text-left">© {new Date().getFullYear()} Karthik Infocom. All rights reserved.</div></div>
    </footer>
  );
}
