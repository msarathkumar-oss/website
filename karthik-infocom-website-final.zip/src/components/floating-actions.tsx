import { Link } from "@tanstack/react-router";
import { ClipboardPenLine, MessageCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { business } from "@/lib/site-data";

export function FloatingActions() {
  return (
    <div className="fixed inset-x-3 bottom-3 z-40 grid grid-cols-3 gap-2 rounded-xl border border-border bg-background/95 p-2 shadow-float backdrop-blur md:inset-x-auto md:right-5 md:flex md:flex-col">
      <Button asChild variant="whatsapp" className="h-11 md:size-12 md:p-0" title="Chat on WhatsApp"><a href={business.whatsappHref} target="_blank" rel="noreferrer" aria-label="Chat with Karthik Infocom on WhatsApp"><MessageCircle /><span className="md:sr-only">WhatsApp</span></a></Button>
      <Button asChild variant="outline" className="h-11 md:size-12 md:p-0" title="Call Karthik Infocom"><a href={business.phoneHref} aria-label="Call Karthik Infocom"><Phone /><span className="md:sr-only">Call</span></a></Button>
      <Button asChild className="h-11 md:size-12 md:p-0" title="Request service"><Link to="/contact" aria-label="Request service"><ClipboardPenLine /><span className="md:sr-only">Request Service</span></Link></Button>
    </div>
  );
}
