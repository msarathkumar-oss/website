import logoAsset from "@/assets/karthik-infocom-logo.jpeg.asset.json";
import { cn } from "@/lib/utils";

export function BrandLogo({ className }: { className?: string }) {
  return (
    <img
      src={logoAsset.url}
      alt="Karthik Infocom"
      width={713}
      height={618}
      className={cn("h-14 w-auto object-contain", className)}
    />
  );
}
