import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, MessageCircle, Phone, X } from "lucide-react";
import { useEffect, useState } from "react";
import { BrandLogo } from "@/components/brand-logo";
import { Button } from "@/components/ui/button";
import { business } from "@/lib/site-data";
import { cn } from "@/lib/utils";

const links = [
  { to: "/" as const, label: "Home" },
  { to: "/services" as const, label: "Services" },
  { to: "/about" as const, label: "About" },
  { to: "/clients" as const, label: "Clients" },
  { to: "/why-us" as const, label: "Why Us" },
  { to: "/process" as const, label: "Process" },
  { to: "/contact" as const, label: "Contact" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => setOpen(false), [pathname]);

  return (
    <header className={cn("sticky top-0 z-50 border-b border-border bg-background/95 transition-all duration-300 backdrop-blur-xl", scrolled && "shadow-nav")}>
      <div className="site-container flex h-20 items-center justify-between gap-3">
        <Link to="/" className="flex shrink-0 items-center" aria-label="Karthik Infocom home">
          <BrandLogo className="h-16 sm:h-17" />
        </Link>
        <nav className="hidden items-center gap-0.5 xl:flex" aria-label="Main navigation">
          {links.map((item) => <Link key={item.to} to={item.to} className="rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-foreground" activeProps={{ className: "bg-accent text-primary" }} activeOptions={{ exact: item.to === "/" }}>{item.label}</Link>)}
        </nav>
        <div className="flex shrink-0 items-center gap-2">
          <Button asChild variant="outline" size="icon" className="hidden size-11 md:inline-flex" title="Chat on WhatsApp"><a href={business.whatsappHref} target="_blank" rel="noreferrer" aria-label="Chat with Karthik Infocom on WhatsApp"><MessageCircle /></a></Button>
          <Button asChild className="hidden h-11 lg:inline-flex"><Link to="/contact">Request Service</Link></Button>
          <Button asChild size="icon" className="size-11 sm:hidden" aria-label="Call Karthik Infocom"><a href={business.phoneHref}><Phone /></a></Button>
          <Button variant="ghost" size="icon" className="size-11 xl:hidden" onClick={() => setOpen((value) => !value)} aria-expanded={open} aria-controls="mobile-navigation" aria-label={open ? "Close menu" : "Open menu"}>{open ? <X /> : <Menu />}</Button>
        </div>
      </div>
      {open && <nav id="mobile-navigation" className="border-t border-border bg-background px-4 py-4 shadow-nav xl:hidden" aria-label="Mobile navigation"><div className="mx-auto grid max-w-7xl gap-1">{links.map((item) => <Link key={item.to} to={item.to} className="rounded-lg px-4 py-3 text-base font-medium text-foreground hover:bg-accent">{item.label}</Link>)}<Button asChild variant="whatsapp" className="mt-2 h-11"><a href={business.whatsappHref} target="_blank" rel="noreferrer"><MessageCircle /> Chat on WhatsApp</a></Button></div></nav>}
    </header>
  );
}
