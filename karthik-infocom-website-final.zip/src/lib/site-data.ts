import {
  BadgeCheck,
  Boxes,
  GraduationCap,
  HardDrive,
  Headphones,
  PackageCheck,
  ShieldCheck,
  Stethoscope,
  Wrench,
  Zap,
} from "lucide-react";

export const business = {
  name: "Karthik Infocom",
  phoneDisplay: "0863-3596305",
  phoneHref: "tel:08633596305",
  whatsappNumber: "919246483486",
  whatsappHref: "https://wa.me/919246483486?text=Hello%20Karthik%20Infocom%2C%20I%20need%20IT%20service%20support.",
  email: "msarathkumar@gmail.com",
  address: "Guntur, Andhra Pradesh, India",
  hours: "Mon–Sat: 10:00 AM – 8:00 PM",
  mapsUrl: "https://maps.app.goo.gl/bBd39wig8pRziq7h8",
};

export const brands = ["Apple", "Samsung", "APC", "TVSE", "Dell", "Lenovo", "HP"];

export const services = [
  {
    slug: "installation",
    icon: Boxes,
    title: "Product Installation",
    summary: "Professional setup, integration and configuration for IT hardware.",
    details: [
      "Complete product setup & configuration",
      "Network interconnection & cabling",
      "Accessories installation",
      "System integration & testing",
      "Post-installation support",
    ],
  },
  {
    slug: "repairs",
    icon: Wrench,
    title: "Repairs & Maintenance",
    summary: "On-site and station repairs for supported brands, before and after warranty.",
    details: [
      "On-site & station repairs",
      "Pre-warranty diagnostics",
      "Post-warranty repairs",
      "Preventive health check-ups",
      "Annual maintenance contracts",
    ],
  },
  {
    slug: "warranty",
    icon: ShieldCheck,
    title: "Extended Warranty",
    summary: "Flexible coverage programs designed to protect your technology investment.",
    details: [
      "Extended coverage plans",
      "Comprehensive parts protection",
      "Priority service access",
      "Flexible plan durations",
      "Transferable warranties",
    ],
  },
  {
    slug: "training",
    icon: GraduationCap,
    title: "Customer Training",
    summary: "Practical product guidance that helps your team work with confidence.",
    details: [
      "Product operation training",
      "Maintenance best practices",
      "Troubleshooting workshops",
      "New feature walkthroughs",
      "Customized training programs",
    ],
  },
  {
    slug: "parts",
    icon: HardDrive,
    title: "Accessories & Parts",
    summary: "Genuine accessories, replacement parts, peripherals and supplies.",
    details: [
      "Original manufacturer parts",
      "Compatible accessories",
      "Peripheral devices",
      "Consumables & supplies",
      "Quick delivery service",
    ],
  },
];

export const advantages = [
  { icon: Headphones, title: "Excellent Support", text: "A dedicated team ready to assist with IT challenges and minimize disruption." },
  { icon: Zap, title: "Fastest Deliveries", text: "Quick turnaround for repairs, installations and parts delivery across Guntur." },
  { icon: BadgeCheck, title: "Competitive Prices", text: "Transparent, competitive pricing without compromising authorized service quality." },
  { icon: Wrench, title: "Experienced Engineers", text: "Certified professionals with hands-on expertise across supported IT brands." },
  { icon: PackageCheck, title: "Maximum Uptime", text: "Efficient service delivery and proactive maintenance designed to reduce downtime." },
  { icon: Stethoscope, title: "Quick Diagnostics", text: "Advanced diagnostic tools help identify and resolve hardware issues efficiently." },
];

export const processSteps = [
  { number: "01", title: "Diagnose", text: "We inspect the device and understand the reported concern." },
  { number: "02", title: "Identify the Issue", text: "Our team isolates the fault and explains the service required." },
  { number: "03", title: "Repair / Replace", text: "Approved repairs or part replacements are completed using proper procedures." },
  { number: "04", title: "Test & Deliver", text: "The device is tested for reliable operation before handover." },
];

export const clients = [
  "Sri Vidya",
  "Kuberalakshmi Enterprises LLP (Tanishq Jewellers)",
  "Lakshmi Annapurna Medical Distributers",
  "Vajram InnPvt Ltd (Kyriad Vajram)",
  "Sree Sobhana EyeWear (Titan Eye)",
  "Lakshmi Harihar Petrolems",
  "Harihar Entertainments",
  "Jayalakshmi Bikes Pvt Ltd",
  "Jayalakshmi Automotives Pvt Ltd",
  "Siva Swathi Textiles Mills Pvt Ltd",
  "Vikram Plywood",
  "Sri Lakshmi Medical Syndicate",
  "Sri Varshini Traders(Visala Traders)",
  "Vasantha Spinners Pvt Ltd",
  "Sri Varalakshmi Spices",
  "Hotel Sindoori",
  "Geetha Regency(Samskruthi EnterprisesPvtLtd)",
  "St.Ann's Novititaes",
  "Vangala Associates",
  "Vangala Logistics",
  "Yerramsetty Auto Services",
  "Sri Lakshmi Enterprises (Caratlane)",
  "Prasuna Vamsi Krishna Spinning Mills Pvt Ltd",
  "CA.Naru Anji Reddy & Co",
  "CA.Mallikarjuna Rao & Co",
  "Kalpana Architects",
  "Saripudi Automotives Pvt Ltd",
  "Sri Anantha Lakshmi Spinning Mills Pvt Ltd",
  "Srinivasa Pharma Distributors Pvt Ltd",
] as const;
